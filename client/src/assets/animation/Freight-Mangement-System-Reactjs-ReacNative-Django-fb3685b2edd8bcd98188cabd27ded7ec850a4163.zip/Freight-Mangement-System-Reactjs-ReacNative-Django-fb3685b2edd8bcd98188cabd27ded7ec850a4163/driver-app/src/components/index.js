import DoubleNavigationPage from './Navigation';
import Footer from './Footer';

export {
    DoubleNavigationPage,
    Footer
}